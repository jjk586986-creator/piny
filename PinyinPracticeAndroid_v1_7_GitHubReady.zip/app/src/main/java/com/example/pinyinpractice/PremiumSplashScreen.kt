package com.example.pinyinpractice

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.animateLottieCompositionAsState
import com.airbnb.lottie.compose.rememberLottieComposition

private val SplashNavy = Color(0xFF08111F)
private val SplashBlue = Color(0xFF5D91FF)
private val SplashText = Color(0xFFF4F7FF)
private val SplashMuted = Color(0xFF91A5C5)

@Composable
internal fun PremiumSplashScreen() {
    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(R.raw.pinyin_splash))
    val orbitProgress by animateLottieCompositionAsState(
        composition = composition,
        iterations = LottieConstants.IterateForever,
        isPlaying = true,
        restartOnPlay = false
    )
    val loadingProgress by animateFloatAsState(
        targetValue = 1f,
        animationSpec = tween(durationMillis = 2200),
        label = "splash-loading"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0B1830), SplashNavy, Color(0xFF070D18))
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width * 0.5f, size.height * 0.43f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF1B4C85).copy(alpha = 0.38f), Color.Transparent),
                    center = center,
                    radius = size.minDimension * 0.56f
                ),
                radius = size.minDimension * 0.56f,
                center = center
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = (-8).dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(0.dp)
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(250.dp)) {
                if (composition != null) {
                    LottieAnimation(
                        composition = composition,
                        progress = { orbitProgress },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF528BFF), Color(0xFF244E9A))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "拼",
                        color = Color.White,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Light
                    )
                }
            }

            Spacer(Modifier.height(7.dp))
            Text(
                text = "PINYIN",
                color = SplashText,
                fontSize = 21.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 6.sp
            )
            Spacer(Modifier.height(11.dp))
            Text(
                text = "拼音打字练习",
                color = Color(0xFFDCE8FA),
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 2.sp
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = "从准确开始，向熟练进阶",
                color = SplashMuted,
                fontSize = 12.sp,
                letterSpacing = 1.2.sp,
                textAlign = TextAlign.Center
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 34.dp, vertical = 42.dp),
            verticalArrangement = Arrangement.spacedBy(11.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "SMART TYPING",
                    color = SplashMuted,
                    fontSize = 9.sp,
                    letterSpacing = 2.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.weight(1f))
                Text(
                    text = "READY TO LEARN",
                    color = Color(0xFF6BA9FF),
                    fontSize = 9.sp,
                    letterSpacing = 1.sp
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFF22314B))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(loadingProgress.coerceIn(0f, 1f))
                        .height(2.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color(0xFF3468D7), Color(0xFF75C8FF))
                            )
                        )
                )
            }
        }
    }
}
