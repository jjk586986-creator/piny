package com.example.pinyinpractice

import android.content.Context
import android.os.Bundle
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class TypingLesson(val category: String, val title: String, val text: String)

private val typingLessons = listOf(
    TypingLesson("基础词语", "基础词语 1", "你好"),
    TypingLesson("基础词语", "基础词语 2", "我们学习"),
    TypingLesson("基础词语", "基础词语 3", "老师和同学"),
    TypingLesson("基础词语", "基础词语 4", "中国汉字"),
    TypingLesson("基础词语", "基础词语 5", "拼音输入法"),
    TypingLesson("基础词语", "基础词语 6", "认真练习"),
    TypingLesson("基础词语", "基础词语 7", "天天进步"),
    TypingLesson("基础词语", "基础词语 8", "谢谢再见"),
    TypingLesson("常用词语", "常用词语 1", "今天明天"),
    TypingLesson("常用词语", "常用词语 2", "学校家庭"),
    TypingLesson("常用词语", "常用词语 3", "电脑手机"),
    TypingLesson("常用词语", "常用词语 4", "天气很好"),
    TypingLesson("常用词语", "常用词语 5", "快乐生活"),
    TypingLesson("常用词语", "常用词语 6", "阅读写作"),
    TypingLesson("常用词语", "常用词语 7", "声母韵母"),
    TypingLesson("常用词语", "常用词语 8", "正确速度"),
    TypingLesson("短句练习", "短句练习 1", "你好，很高兴认识你。"),
    TypingLesson("短句练习", "短句练习 2", "我正在练习中文打字。"),
    TypingLesson("短句练习", "短句练习 3", "请慢慢输入每一个汉字。"),
    TypingLesson("短句练习", "短句练习 4", "先保证正确，再提高速度。"),
    TypingLesson("短句练习", "短句练习 5", "每天练习十分钟，坚持就会进步。"),
    TypingLesson("短句练习", "短句练习 6", "读准声母、韵母和声调。"),
    TypingLesson("短句练习", "短句练习 7", "熟练掌握拼音，打字会越来越快。"),
    TypingLesson("短句练习", "短句练习 8", "认真看清目标文字，再开始输入。"),
    TypingLesson("段落练习", "段落练习 1", "学习拼音需要耐心。先认识声母和韵母，再练习完整音节。每次练习时，都要认真看、仔细输入。"),
    TypingLesson("段落练习", "段落练习 2", "打字练习不必一味追求速度。先把每个字输入正确，再慢慢提高速度。坚持练习，就能逐渐进步。"),
    TypingLesson("段落练习", "段落练习 3", "每天抽出一点时间练习打字。输入时注意标点和顺序，发现错误就及时修改。熟能生巧，进步来自坚持。"),
    TypingLesson("段落练习", "段落练习 4", "汉语拼音可以帮助我们认识汉字。使用拼音输入法时，先输入读音，再从候选字中选择正确的汉字。"),
    TypingLesson("段落练习", "段落练习 5", "熟练的打字能力来自持续练习。开始时速度慢一点没有关系，重要的是准确输入，并逐步完成更长的内容。")
)

private val Ink = Color(0xFF17233C)
private val Muted = Color(0xFF64718A)
private val Blue = Color(0xFF4169E1)
private val Page = Color(0xFFF4F6FA)
private val Green = Color(0xFF18865C)
private val Red = Color(0xFFB42318)
private val SoftBlue = Color(0xFFEAF0FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // Native Android splash first; Compose + Lottie keeps the branded opening page visible.
        installSplashScreen()
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 17, 31)
        window.navigationBarColor = android.graphics.Color.rgb(8, 17, 31)
        setContent {
            MaterialTheme {
                var showSplash by remember { mutableStateOf(true) }
                LaunchedEffect(Unit) {
                    delay(2200L)
                    showSplash = false
                }
                Box(modifier = Modifier.fillMaxSize()) {
                    PinyinApp(this@MainActivity)
                    AnimatedVisibility(
                        visible = showSplash,
                        exit = fadeOut(animationSpec = tween(durationMillis = 420))
                    ) {
                        PremiumSplashScreen()
                    }
                }
            }
        }
    }
}

@Composable
private fun PinyinApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("pinyin_typing", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()

    var lessonIndex by remember { mutableIntStateOf(prefs.getInt("lesson_index", 0).coerceIn(0, typingLessons.lastIndex)) }
    var typed by remember { mutableStateOf("") }
    var completed by remember { mutableStateOf(false) }
    var checkedMessage by remember { mutableStateOf("") }
    var startTime by remember { mutableStateOf(System.currentTimeMillis()) }
    var finishTime by remember { mutableStateOf<Long?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    var completedLessons by remember { mutableIntStateOf(prefs.getInt("completed_lessons", 0)) }
    var totalTypedChars by remember { mutableIntStateOf(prefs.getInt("total_typed_chars", 0)) }
    var totalCorrectChars by remember { mutableIntStateOf(prefs.getInt("total_correct_chars", 0)) }

    var token by remember { mutableStateOf(prefs.getString("token", "").orEmpty()) }
    var username by remember { mutableStateOf(prefs.getString("username", "").orEmpty()) }
    var showAccount by remember { mutableStateOf(false) }
    var authMode by remember { mutableStateOf("登录") }
    var authUser by remember { mutableStateOf("") }
    var authPassword by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("输入上方文字即可开始练习") }

    val lesson = typingLessons[lessonIndex]
    val target = lesson.text
    val comparedLength = minOf(typed.length, target.length)
    val matchedChars = (0 until comparedLength).count { typed[it] == target[it] }
    val errorChars = comparedLength - matchedChars + (typed.length - target.length).coerceAtLeast(0)
    val currentAccuracy = if (typed.isEmpty()) 100 else (matchedChars * 100 / typed.length).coerceIn(0, 100)
    val elapsedSeconds = (((finishTime ?: System.currentTimeMillis()) - startTime) / 1000L).coerceAtLeast(1L)
    val currentSpeed = matchedChars * 60 / elapsedSeconds.toInt().coerceAtLeast(1)
    val shownProgress = (typed.length.toFloat() / target.length.coerceAtLeast(1)).coerceIn(0f, 1f)

    fun saveStats() {
        prefs.edit()
            .putInt("lesson_index", lessonIndex)
            .putInt("completed_lessons", completedLessons)
            .putInt("total_typed_chars", totalTypedChars)
            .putInt("total_correct_chars", totalCorrectChars)
            .apply()
    }

    fun completeLesson() {
        if (completed) return
        val now = System.currentTimeMillis()
        val elapsed = (((now - startTime) / 1000L).coerceAtLeast(1L))
        completed = true
        finishTime = now
        completedLessons++
        totalTypedChars += target.length
        totalCorrectChars += target.length
        val speed = target.length * 60 / elapsed.toInt().coerceAtLeast(1)
        checkedMessage = "本段完成！用时 ${elapsed} 秒，速度约 ${speed} 字/分钟。"
        saveStats()
    }

    fun openLesson(newIndex: Int) {
        lessonIndex = newIndex.coerceIn(0, typingLessons.lastIndex)
        typed = ""
        completed = false
        checkedMessage = ""
        startTime = System.currentTimeMillis()
        finishTime = null
        tick = 0
        saveStats()
    }

    LaunchedEffect(lessonIndex, completed) {
        while (!completed) {
            delay(1000)
            tick++
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Page) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("拼音打字练习", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("金山打字式练习 · 对照文字输入 · 先准确再提速", fontSize = 12.sp, color = Muted)
                }
                Box(Modifier.size(48.dp).background(SoftBlue, RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                    Text("打", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Blue)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = {
                        busy = true
                        scope.launch {
                            message = try {
                                val result = withContext(Dispatchers.IO) { ApiClient.health() }
                                "服务器连接成功：${result.optString("status", "ok")}"
                            } catch (e: Exception) { "连接失败：${e.message ?: "请检查服务器地址"}" }
                            busy = false
                        }
                    }, modifier = Modifier.weight(1f)
                ) { Text(if (busy) "请稍候…" else "测试服务器") }
                OutlinedButton(onClick = { showAccount = !showAccount }, modifier = Modifier.weight(1f)) {
                    Text(if (showAccount) "返回练习" else if (token.isBlank()) "账号/同步" else "账号：$username")
                }
            }
            if (message.isNotBlank()) Text(message, color = if (message.contains("成功")) Green else Muted, fontSize = 12.sp)

            if (showAccount) {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(if (token.isBlank()) "账号与云端同步" else "账号：$username", fontWeight = FontWeight.Bold, color = Ink, fontSize = 19.sp)
                        if (token.isBlank()) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { authMode = "登录" }, modifier = Modifier.weight(1f)) { Text(if (authMode == "登录") "✓ 登录" else "登录") }
                                OutlinedButton(onClick = { authMode = "注册" }, modifier = Modifier.weight(1f)) { Text(if (authMode == "注册") "✓ 注册" else "注册") }
                            }
                            OutlinedTextField(value = authUser, onValueChange = { authUser = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("用户名（3–32 位）") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next))
                            OutlinedTextField(value = authPassword, onValueChange = { authPassword = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("密码（至少 8 位）") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done))
                            Button(onClick = {
                                val u = authUser.trim(); val p = authPassword
                                if (!u.matches(Regex("^[A-Za-z0-9_.-]{3,32}$")) || p.length < 8) {
                                    message = "用户名需 3–32 位英文字母、数字、点、下划线或短横线，密码至少 8 位。"
                                    return@Button
                                }
                                busy = true
                                scope.launch {
                                    try {
                                        val result = withContext(Dispatchers.IO) { if (authMode == "注册") ApiClient.register(u, p) else ApiClient.login(u, p) }
                                        token = result.getString("access_token")
                                        username = result.optJSONObject("user")?.optString("username", u) ?: u
                                        prefs.edit().putString("token", token).putString("username", username).apply()
                                        val remote = withContext(Dispatchers.IO) { ApiClient.getProgress(token) }
                                        lessonIndex = remote.optInt("current_index", lessonIndex).coerceIn(0, typingLessons.lastIndex)
                                        totalTypedChars = remote.optInt("attempts", totalTypedChars).coerceAtLeast(0)
                                        totalCorrectChars = remote.optInt("correct", totalCorrectChars).coerceAtLeast(0)
                                        saveStats(); showAccount = false; typed = ""; completed = false; startTime = System.currentTimeMillis(); finishTime = null
                                        message = "${authMode}成功，已读取云端记录。"
                                    } catch (e: Exception) { message = "${authMode}失败：${e.message ?: "网络错误"}" }
                                    busy = false
                                }
                            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "正在处理…" else authMode) }
                            Text("当前服务器使用 HTTP 测试地址，请勿输入重要密码。正式使用前应改为 HTTPS。", color = Red, fontSize = 12.sp)
                        } else {
                            Button(onClick = {
                                busy = true
                                scope.launch {
                                    try {
                                        withContext(Dispatchers.IO) { ApiClient.putProgress(token, lessonIndex, totalTypedChars, totalCorrectChars) }
                                        message = "云端同步成功。"
                                    } catch (e: Exception) { message = "同步失败：${e.message ?: "网络错误"}" }
                                    busy = false
                                }
                            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "同步中…" else "立即同步练习记录") }
                            OutlinedButton(onClick = { token = ""; username = ""; prefs.edit().remove("token").remove("username").apply(); message = "已退出账号，本机记录仍保留。" }, modifier = Modifier.fillMaxWidth()) { Text("退出登录") }
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("基础词语", "常用词语", "短句练习", "段落练习").forEach { category ->
                        val selected = lesson.category == category
                        if (selected) {
                            Button(onClick = { openLesson(typingLessons.indexOfFirst { it.category == category }) }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 8.dp)) { Text(category) }
                        } else {
                            OutlinedButton(onClick = { openLesson(typingLessons.indexOfFirst { it.category == category }) }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 8.dp)) { Text(category) }
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(lesson.title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                Text("第 ${lessonIndex + 1} / ${typingLessons.size} 段", color = Muted, fontSize = 12.sp)
                            }
                            if (completed) Text("已完成 ✓", color = Green, fontWeight = FontWeight.Bold)
                        }
                        LinearProgressIndicator(
                            progress = { (lessonIndex + if (completed) 1f else shownProgress) / typingLessons.size.toFloat() },
                            modifier = Modifier.fillMaxWidth().height(7.dp), color = Blue, trackColor = Color(0xFFE9EDF5)
                        )
                        Text("目标文字", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        val coloredTarget = buildAnnotatedString {
                            target.forEachIndexed { i, c ->
                                val color = when {
                                    i >= typed.length -> Ink
                                    typed[i] == c -> Green
                                    else -> Red
                                }
                                withStyle(SpanStyle(color = color, fontWeight = FontWeight.SemiBold)) { append(c) }
                            }
                        }
                        Text(
                            coloredTarget,
                            modifier = Modifier.fillMaxWidth().background(Color(0xFFF8FAFD), RoundedCornerShape(14.dp)).padding(15.dp),
                            fontSize = 23.sp, lineHeight = 37.sp, textAlign = TextAlign.Start
                        )
                        Text("输入区：切换到手机拼音输入法，照着上方内容输入。输入正确显示绿色，位置不一致显示红色。", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                        OutlinedTextField(
                            value = typed,
                            onValueChange = { value ->
                                if (!completed) {
                                    typed = value
                                    checkedMessage = ""
                                    if (value == target) completeLesson()
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !completed,
                            minLines = if (target.length > 24) 3 else 2,
                            maxLines = 5,
                            label = { Text("在这里输入上方文字") },
                            placeholder = { Text("点击后开始打字……") },
                            shape = RoundedCornerShape(14.dp),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Default)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            MiniStat("输入进度", "${typed.length.coerceAtMost(target.length)}/${target.length}", Modifier.weight(1f))
                            MiniStat("正确率", "$currentAccuracy%", Modifier.weight(1f))
                            MiniStat("速度", "${currentSpeed} 字/分", Modifier.weight(1f))
                        }
                        Text("当前不匹配字符：$errorChars　·　用时：${elapsedSeconds} 秒", color = if (errorChars > 0) Red else Muted, fontSize = 12.sp)
                        if (checkedMessage.isNotBlank()) {
                            Text(checkedMessage, color = if (completed) Green else Red, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = {
                                    typed = ""; completed = false; checkedMessage = ""; startTime = System.currentTimeMillis(); finishTime = null; tick = 0
                                }, modifier = Modifier.weight(1f)
                            ) { Text("重练本段") }
                            Button(
                                onClick = {
                                    if (!completed && typed == target) completeLesson()
                                    openLesson((lessonIndex + 1) % typingLessons.size)
                                }, modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Blue)
                            ) { Text(if (lessonIndex == typingLessons.lastIndex) "重新开始" else if (completed) "下一段 →" else "跳过本段 →") }
                        }
                        if (!completed && typed.isNotEmpty()) {
                            OutlinedButton(onClick = {
                                checkedMessage = if (typed == target) "本段完成！" else "还没完全匹配：请检查红色位置，并留意标点符号。"
                            }, modifier = Modifier.fillMaxWidth()) { Text("检查本段") }
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                    MiniStat("累计完成", "$completedLessons 段", Modifier.weight(1f))
                    MiniStat("累计正确字", "$totalCorrectChars", Modifier.weight(1f))
                    MiniStat("课程数量", "${typingLessons.size} 段", Modifier.weight(1f))
                }
                Card(colors = CardDefaults.cardColors(containerColor = SoftBlue), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("练习提示", color = Ink, fontWeight = FontWeight.Bold)
                        Text("像金山打字一样，按顺序把目标文本完整输入。先追求准确率，再逐步提高字/分钟。每段完成后点击“下一段”，也可以切换词语、短句和段落练习。", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun MiniStat(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center)
            Text(value, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
    }
}
