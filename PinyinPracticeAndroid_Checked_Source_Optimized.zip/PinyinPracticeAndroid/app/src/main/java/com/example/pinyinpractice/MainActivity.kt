package com.example.pinyinpractice

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class PracticeItem(val finalGroup: String, val pinyin: String, val target: String)
private val practiceItems = listOf(
    PracticeItem("单韵母 a", "ā", "啊"), PracticeItem("单韵母 o", "ó", "哦"),
    PracticeItem("单韵母 e", "è", "饿"), PracticeItem("单韵母 i", "yī", "衣"),
    PracticeItem("单韵母 u", "wū", "乌"), PracticeItem("单韵母 ü", "yú", "鱼"),
    PracticeItem("复韵母 ai", "ài", "爱"), PracticeItem("复韵母 ei", "ēi", "诶"),
    PracticeItem("复韵母 ui", "huì", "会"), PracticeItem("复韵母 ao", "hǎo", "好"),
    PracticeItem("复韵母 ou", "ōu", "欧"), PracticeItem("复韵母 iu", "liù", "六"),
    PracticeItem("复韵母 ie", "xiè", "谢"), PracticeItem("复韵母 üe", "yuè", "月"),
    PracticeItem("特殊韵母 er", "ér", "儿"), PracticeItem("前鼻韵母 an", "ān", "安"),
    PracticeItem("前鼻韵母 en", "ēn", "恩"), PracticeItem("前鼻韵母 in", "yīn", "音"),
    PracticeItem("前鼻韵母 un", "chūn", "春"), PracticeItem("前鼻韵母 ün", "yún", "云"),
    PracticeItem("后鼻韵母 ang", "máng", "忙"), PracticeItem("后鼻韵母 eng", "fēng", "风"),
    PracticeItem("后鼻韵母 ing", "xīng", "星"), PracticeItem("后鼻韵母 ong", "zhōng", "中")
)
private val Ink = Color(0xFF17233C)
private val Muted = Color(0xFF64718A)
private val Blue = Color(0xFF4169E1)
private val Page = Color(0xFFF5F7FB)
private val Green = Color(0xFF18865C)
private val Red = Color(0xFFB42318)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { PinyinApp(this) } }
    }
}

@Composable
private fun PinyinApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("pinyin_practice", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var token by remember { mutableStateOf(prefs.getString("token", null).orEmpty()) }
    var username by remember { mutableStateOf(prefs.getString("username", "").orEmpty()) }
    var index by remember { mutableIntStateOf(prefs.getInt("index", 0).coerceIn(0, practiceItems.lastIndex)) }
    var typed by remember { mutableStateOf("") }
    var wrongIndices by remember { mutableStateOf(prefs.getString("wrong_indices", "").orEmpty().split(",").mapNotNull { it.toIntOrNull() }.filter { it in practiceItems.indices }.toSet()) }
    var selectedAnswer by remember { mutableStateOf<String?>(null) }
    var streak by remember { mutableIntStateOf(prefs.getInt("streak", 0)) }
    var attempts by remember { mutableIntStateOf(prefs.getInt("attempts", 0)) }
    var correct by remember { mutableIntStateOf(prefs.getInt("correct", 0)) }
    var checked by remember { mutableStateOf(false) }
    var isCorrect by remember { mutableStateOf(false) }
    var authMode by remember { mutableStateOf("登录") }
    var authUser by remember { mutableStateOf("") }
    var authPassword by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("尚未测试服务器连接") }
    var busy by remember { mutableStateOf(false) }
    var showAccount by remember { mutableStateOf(token.isBlank()) }
    val item = practiceItems[index]
    val accuracy = if (attempts == 0) 0 else correct * 100 / attempts

    fun saveLocal() {
        prefs.edit().putInt("index", index).putInt("attempts", attempts).putInt("correct", correct).putInt("streak", streak).putString("wrong_indices", wrongIndices.joinToString(",")).apply()
    }
    fun syncNow() {
        if (token.isBlank()) { message = "请先登录账号，再同步成绩。"; return }
        busy = true
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { ApiClient.putProgress(token, index, attempts, correct) }
                message = "云端同步成功：${result.optString("message", "成绩已保存")}" 
            } catch (e: Exception) { message = "同步失败：${e.message ?: "网络错误"}" }
            busy = false
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Page) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("拼音打字练习", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text(if (token.isNotBlank()) "已登录：$username · 云端可同步" else "按韵母顺序练习 · 本机自动保存", fontSize = 12.sp, color = Muted)
                }
                Box(Modifier.size(46.dp).background(Color(0xFFE6ECFF), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) { Text("拼", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Blue) }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = {
                    busy = true
                    scope.launch {
                        message = try { val r = withContext(Dispatchers.IO) { ApiClient.health() }; "服务器连接成功：${r.optString("status", "ok")}" }
                        catch (e: Exception) { "连接失败：${e.message ?: "请检查服务器地址、端口和防火墙"}" }
                        busy = false
                    }
                }, modifier = Modifier.weight(1f)) { Text(if (busy) "请稍候…" else "测试服务器") }
                OutlinedButton(onClick = { showAccount = !showAccount }, modifier = Modifier.weight(1f)) { Text(if (showAccount) "返回练习" else if (token.isBlank()) "账号登录" else "账号/退出") }
            }
            Text(message, color = if (message.contains("成功")) Green else Muted, fontSize = 12.sp)

            if (showAccount) {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(if (token.isNotBlank()) "账号状态" else "账号与云端同步", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
                        if (token.isNotBlank()) {
                            Text("当前账号：$username", color = Muted)
                            Button(onClick = { syncNow() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("立即同步练习成绩") }
                            OutlinedButton(onClick = {
                                token = ""; username = ""; showAccount = true
                                prefs.edit().remove("token").remove("username").apply()
                                message = "已退出当前账号，本机练习记录仍保留。"
                            }, modifier = Modifier.fillMaxWidth()) { Text("退出登录") }
                        } else {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { authMode = "登录" }, modifier = Modifier.weight(1f)) { Text(if (authMode == "登录") "✓ 登录" else "登录") }
                                OutlinedButton(onClick = { authMode = "注册" }, modifier = Modifier.weight(1f)) { Text(if (authMode == "注册") "✓ 注册" else "注册") }
                            }
                            OutlinedTextField(value = authUser, onValueChange = { authUser = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("用户名（3–32 位：字母、数字、._-）") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next))
                            OutlinedTextField(value = authPassword, onValueChange = { authPassword = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("密码（至少 8 位）") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done))
                            Button(onClick = {
                                val u = authUser.trim(); val p = authPassword
                                if (!u.matches(Regex("^[A-Za-z0-9_.-]{3,32}$")) || p.length < 8) {
                                    message = "用户名需 3–32 位（仅限英文字母、数字、点、下划线、短横线），密码至少 8 位。"
                                    return@Button
                                }
                                busy = true
                                scope.launch {
                                    try {
                                        val r = withContext(Dispatchers.IO) { if (authMode == "注册") ApiClient.register(u, p) else ApiClient.login(u, p) }
                                        token = r.getString("access_token"); username = r.optJSONObject("user")?.optString("username", u) ?: u
                                        prefs.edit().putString("token", token).putString("username", username).apply()
                                        val remote = withContext(Dispatchers.IO) { ApiClient.getProgress(token) }
                                        index = remote.optInt("current_index", index).coerceIn(0, practiceItems.lastIndex)
                                        attempts = remote.optInt("attempts", attempts).coerceAtLeast(0)
                                        correct = remote.optInt("correct", correct).coerceIn(0, attempts)
                                        saveLocal(); showAccount = false; typed = ""; checked = false
                                        message = "${authMode}成功，已读取云端练习进度。"
                                    } catch (e: Exception) { message = "${authMode}失败：${e.message ?: "网络错误"}" }
                                    busy = false
                                }
                            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "正在处理…" else authMode) }
                            Text("提示：当前配置为 HTTP 测试地址，请勿使用真实或重要密码。正式使用前必须部署 HTTPS。", color = Red, fontSize = 12.sp, lineHeight = 18.sp)
                        }
                    }
                }
            } else {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("练习进度", color = Muted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Text("${index + 1} / ${practiceItems.size}", color = Blue, fontWeight = FontWeight.SemiBold)
                        }
                        LinearProgressIndicator(progress = { (index + 1f) / practiceItems.size }, modifier = Modifier.fillMaxWidth().height(7.dp), color = Blue, trackColor = Color(0xFFE9EDF5))
                        Text(item.finalGroup, color = Blue, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(item.pinyin, fontSize = 45.sp, fontWeight = FontWeight.Bold, color = Ink)
                            Text("看拼音，选择对应汉字", fontSize = 13.sp, color = Muted)
                        }
                        val choices = remember(index) {
                            (listOf(item.target) + practiceItems.filter { it.target != item.target }.shuffled(kotlin.random.Random(index)).map { it.target }.distinct().take(3)).shuffled(kotlin.random.Random(index + 77))
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                            choices.chunked(2).forEach { pair ->
                                Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                                    pair.forEach { choice ->
                                        val chosen = selectedAnswer == choice
                                        OutlinedButton(
                                            onClick = {
                                                if (!checked) {
                                                    selectedAnswer = choice
                                                    isCorrect = choice == item.target
                                                    attempts++
                                                    if (isCorrect) { correct++; streak++ } else { streak = 0; wrongIndices = wrongIndices + index }
                                                    checked = true
                                                    saveLocal()
                                                }
                                            }, enabled = !checked, modifier = Modifier.weight(1f).height(58.dp),
                                            shape = RoundedCornerShape(14.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(
                                                containerColor = if (checked && choice == item.target) Color(0xFFE4F7EC) else if (checked && chosen && !isCorrect) Color(0xFFFFE9E7) else Color.White,
                                                contentColor = if (checked && choice == item.target) Green else Ink
                                            )
                                        ) { Text(choice, fontSize = 25.sp, fontWeight = FontWeight.SemiBold) }
                                    }
                                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                        if (checked) Text(if (isCorrect) "答对了！连续答对 $streak 题" else "正确答案：${item.target}，已加入错题复习", color = if (isCorrect) Green else Red, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick = { index = (index + 1) % practiceItems.size; selectedAnswer = null; checked = false; isCorrect = false; saveLocal() }, modifier = Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(14.dp)) { Text(if (index == practiceItems.lastIndex) "重新开始" else "下一题") }
                            Button(onClick = {
                                val nextWrong = wrongIndices.sorted().firstOrNull { it > index } ?: wrongIndices.minOrNull()
                                if (nextWrong != null) { index = nextWrong; selectedAnswer = null; checked = false; isCorrect = false; saveLocal() }
                            }, enabled = wrongIndices.isNotEmpty(), modifier = Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text("错题复习 ${wrongIndices.size}") }
                        }
                        Button(onClick = { syncNow() }, enabled = token.isNotBlank() && !busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(if (busy) "正在同步…" else "同步到云端") }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    StatCard("累计答题", "$attempts", Modifier.weight(1f)); StatCard("答对题数", "$correct", Modifier.weight(1f)); StatCard("正确率", "$accuracy%", Modifier.weight(1f))
                }
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF3FF)), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("连接信息", fontWeight = FontWeight.Bold, color = Ink)
                        Text("服务器：${ApiClient.BASE_URL}\n接口：/health、/api/register、/api/login、/api/progress", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                        Text("若接口不存在，请部署项目内 backend/main.py；当前网络地址为 HTTP，仅供联调。", color = Red, fontSize = 12.sp, lineHeight = 18.sp)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 15.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, color = Ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        }
    }
}
