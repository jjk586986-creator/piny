# 拼音打字练习 Android 项目（含 API 接入）

原生 Android 项目，技术栈 Kotlin + Jetpack Compose。可以在 Android Studio 打开并运行。

## 功能
- 按单韵母、复韵母、前鼻韵母、后鼻韵母顺序练习
- 题目显示拼音和汉字，中文输入法提交答案
- 答题数量、正确题数、正确率和当前题号保存在本机
- 账号注册/登录 UI
- “测试服务器”按钮调用 `GET /health`
- 登录后读取云端进度，手动同步本地练习进度
- 配套 FastAPI 后端在 `backend/main.py`

## 重要：连接当前服务器
客户端默认地址 `http://47.88.2.116:8000`。我无法从创建项目的执行环境连接到这个 IP，因此不能替你确认你的服务器是否对手机公网可达，也不能确认线上服务已包含配套接口。

如果服务器 `/docs` 没有 `/api/register`、`/api/login`、`/api/progress`，请按 `backend/README_DEPLOY_CN.md` 部署配套后端。Android 原生请求不需要配置 CORS。

**安全注意：** 当前 HTTP 只用于联调演示，不要使用重要/重复密码。生产环境请先部署 HTTPS，然后更新 `ApiClient.kt` 的 `BASE_URL` 并禁用 cleartext traffic。

## Windows 上打开
1. 解压 ZIP。
2. 安装 Android Studio。
3. 在 Android Studio 选择 Open，打开此文件夹 `PinyinPracticeAndroid`。
4. 安装提示需要的 Android SDK 35 和 JDK 17。
5. 等待 Gradle Sync，再连接手机（启用开发者选项和 USB 调试）或启动模拟器，点击 Run。

## 常见问题
- 若提示 SDK 35 缺失：在 Android Studio SDK Manager 中安装 Android SDK Platform 35。
- 若连接失败：先在手机浏览器检查 `http://47.88.2.116:8000/health` 是否能打开，再检查阿里云安全组和服务器防火墙是否允许 TCP 8000（仅作联调；生产应改为 HTTPS 443）。
- 如果端口可以打开但注册接口 404：当前服务器还没部署本包 `backend/main.py` 的配套 API。

## 构建说明
本项目未包含 Gradle Wrapper JAR，也未在这里实际编译或连真机测试。建议在 Android Studio 打开后同步和构建；项目所需文件已提供。
