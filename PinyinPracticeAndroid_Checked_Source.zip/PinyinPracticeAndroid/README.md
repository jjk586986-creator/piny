# 拼音打字练习 Android 项目（1.6 金山打字式界面）

原生 Android 项目，技术栈 Kotlin + Jetpack Compose，面向手机使用。

## 1.6 版本重点
- 移除随机选择汉字、猜声母、猜韵母等杂乱问答界面。
- 改为金山打字式逐段输入：上方显示目标文本，下方使用手机拼音输入法输入相同内容。
- 输入区域随输入即时显示进度、当前正确率、速度（字/分钟）和不匹配字符数。
- 已输入且匹配的目标字符显示绿色，不匹配的位置显示红色。
- 按难度分为基础词语、常用词语、短句练习、段落练习，共 29 段文字；完成后可以进入下一段，也可以重练或跳过。
- 本机保存课程位置、累计完成段数和累计正确字数。
- 保留服务器连通性测试、账号注册/登录与总体成绩同步入口。

## 练习方式
1. 选择“基础词语”“常用词语”“短句练习”或“段落练习”。
2. 对照上方的目标文字，点下方输入区。
3. 使用手机当前的中文拼音输入法，把目标文字完整输入。标点符号也要一致。
4. 绿色表示对应位置正确，红色表示不一致；修改后可继续检查。
5. 整段完全匹配后显示完成提示，再点击“下一段”。

本版本属于中文输入法打字练习：输入区需要使用系统中文拼音输入法。它不是通过选择题学习拼音的问答游戏。

## 服务器与账号
客户端默认地址为 `http://47.88.2.116:8000`。可点击“测试服务器”验证 `/health`，账号页提供注册/登录和总体记录同步。当前 HTTP 只适合测试联调，请勿使用重要或重复密码；正式使用前应部署 HTTPS 并更新 `ApiClient.kt` 的地址。

配套 FastAPI 后端位于 `backend/main.py`。如果服务器 `/docs` 中没有 `/api/register`、`/api/login`、`/api/progress`，请按 `backend/README_DEPLOY_CN.md` 部署。

## Windows / Android Studio 构建
1. 解压 ZIP。
2. 在 Android Studio 中打开 `PinyinPracticeAndroid` 文件夹。
3. 使用 JDK 17，安装 Android SDK Platform 35。
4. 等待 Gradle Sync 后构建或连接手机运行。

项目未包含 Gradle Wrapper JAR。当前创建环境没有 Android SDK，因此此次只完成了源码修改和 ZIP 完整性检查，尚未本地执行 Android 编译或真机验证。请通过仓库的 GitHub Actions 编译 1.6 版本，确认成功后再安装 APK。


## 1.7 高级简约开屏页

新增 AndroidX SplashScreen 与 Lottie Compose 开屏动画，资源见 `app/src/main/res/raw/pinyin_splash.json`。详细导入方法见 `SPLASH_Lottie_使用说明_CN.txt`。
