package com.example.pinyinpractice

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/** Change this value if your server address changes. Use HTTPS before sending real passwords. */
object ApiClient {
    const val BASE_URL = "http://47.88.2.116:8000"

    private fun request(method: String, path: String, body: JSONObject? = null, token: String? = null): JSONObject {
        val conn = (URL(BASE_URL.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("Accept", "application/json")
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            if (!token.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $token")
        }
        try {
            if (body != null) conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.use { input -> BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText() }.orEmpty()
            val obj = try { if (text.isBlank()) JSONObject() else JSONObject(text) } catch (_: Exception) { JSONObject().put("detail", text) }
            if (code !in 200..299) throw IllegalStateException(obj.optString("detail", "HTTP $code"))
            return obj
        } finally { conn.disconnect() }
    }

    fun health() = request("GET", "/health")

    fun register(username: String, password: String) = request("POST", "/api/register", JSONObject().put("username", username).put("password", password))

    fun login(username: String, password: String) = request("POST", "/api/login", JSONObject().put("username", username).put("password", password))

    fun getProgress(token: String) = request("GET", "/api/progress", token = token)

    fun putProgress(token: String, index: Int, attempts: Int, correct: Int) = request(
        "PUT", "/api/progress",
        JSONObject().put("current_index", index).put("attempts", attempts).put("correct", correct), token
    )
}
