package com.example.pinyinpractice

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private data class PracticeItem(val finalGroup: String, val pinyin: String, val target: String)
private val practiceItems = listOf(
    PracticeItem("单韵母 a", "ā", "啊"),
    PracticeItem("单韵母 o", "ó", "哦"),
    PracticeItem("单韵母 e", "è", "饿"),
    PracticeItem("单韵母 i", "yī", "衣"),
    PracticeItem("单韵母 u", "wū", "乌"),
    PracticeItem("单韵母 ü", "yú", "鱼"),
    PracticeItem("复韵母 ai", "ài", "爱"),
    PracticeItem("复韵母 ei", "ēi", "诶"),
    PracticeItem("复韵母 ui", "huì", "会"),
    PracticeItem("复韵母 ao", "hǎo", "好"),
    PracticeItem("复韵母 ou", "ōu", "欧"),
    PracticeItem("复韵母 iu", "liù", "六"),
    PracticeItem("复韵母 ie", "xiè", "谢"),
    PracticeItem("复韵母 üe", "yuè", "月"),
    PracticeItem("特殊韵母 er", "ér", "儿"),
    PracticeItem("前鼻韵母 an", "ān", "安"),
    PracticeItem("前鼻韵母 en", "ēn", "恩"),
    PracticeItem("前鼻韵母 in", "yīn", "音"),
    PracticeItem("前鼻韵母 un", "chūn", "春"),
    PracticeItem("前鼻韵母 ün", "yún", "云"),
    PracticeItem("后鼻韵母 ang", "máng", "忙"),
    PracticeItem("后鼻韵母 eng", "fēng", "风"),
    PracticeItem("后鼻韵母 ing", "xīng", "星"),
    PracticeItem("后鼻韵母 ong", "zhōng", "中"),
    PracticeItem("声母 b", "bā", "八"),
    PracticeItem("声母 b", "bǐ", "笔"),
    PracticeItem("声母 b", "bù", "不"),
    PracticeItem("声母 p", "pí", "皮"),
    PracticeItem("声母 p", "pā", "趴"),
    PracticeItem("声母 p", "pǔ", "普"),
    PracticeItem("声母 m", "mā", "妈"),
    PracticeItem("声母 m", "mǐ", "米"),
    PracticeItem("声母 m", "mù", "木"),
    PracticeItem("声母 f", "fā", "发"),
    PracticeItem("声母 f", "fó", "佛"),
    PracticeItem("声母 f", "fú", "福"),
    PracticeItem("声母 d", "dà", "大"),
    PracticeItem("声母 d", "dǐ", "底"),
    PracticeItem("声母 d", "dǒu", "斗"),
    PracticeItem("声母 t", "tā", "他"),
    PracticeItem("声母 t", "tǔ", "土"),
    PracticeItem("声母 t", "tí", "提"),
    PracticeItem("声母 n", "nǐ", "你"),
    PracticeItem("声母 n", "nán", "南"),
    PracticeItem("声母 n", "nǚ", "女"),
    PracticeItem("声母 l", "lái", "来"),
    PracticeItem("声母 l", "lǐ", "里"),
    PracticeItem("声母 l", "lù", "路"),
    PracticeItem("声母 g", "gē", "歌"),
    PracticeItem("声母 g", "gǔ", "古"),
    PracticeItem("声母 g", "gāo", "高"),
    PracticeItem("声母 k", "kāi", "开"),
    PracticeItem("声母 k", "kǒu", "口"),
    PracticeItem("声母 k", "kù", "裤"),
    PracticeItem("声母 h", "hē", "喝"),
    PracticeItem("声母 h", "hú", "湖"),
    PracticeItem("声母 h", "hǎi", "海"),
    PracticeItem("声母 j", "jī", "鸡"),
    PracticeItem("声母 j", "jiā", "家"),
    PracticeItem("声母 j", "jǔ", "举"),
    PracticeItem("声母 q", "qī", "七"),
    PracticeItem("声母 q", "qián", "钱"),
    PracticeItem("声母 q", "qù", "去"),
    PracticeItem("声母 x", "xī", "西"),
    PracticeItem("声母 x", "xiǎo", "小"),
    PracticeItem("声母 x", "xué", "学"),
    PracticeItem("声母 zh", "zhǎo", "找"),
    PracticeItem("声母 zh", "zhǔ", "主"),
    PracticeItem("声母 ch", "chī", "吃"),
    PracticeItem("声母 ch", "chū", "出"),
    PracticeItem("声母 ch", "cháng", "长"),
    PracticeItem("声母 sh", "shū", "书"),
    PracticeItem("声母 sh", "shān", "山"),
    PracticeItem("声母 sh", "shí", "十"),
    PracticeItem("声母 r", "rén", "人"),
    PracticeItem("声母 r", "rì", "日"),
    PracticeItem("声母 r", "ròu", "肉"),
    PracticeItem("声母 z", "zǒu", "走"),
    PracticeItem("声母 z", "zì", "字"),
    PracticeItem("声母 z", "zǎo", "早"),
    PracticeItem("声母 c", "cāi", "猜"),
    PracticeItem("声母 c", "cì", "次"),
    PracticeItem("声母 c", "cūn", "村"),
    PracticeItem("声母 s", "sān", "三"),
    PracticeItem("声母 s", "sì", "四"),
    PracticeItem("声母 s", "sòng", "送"),
    PracticeItem("声母 y", "yǔ", "雨"),
    PracticeItem("声母 y", "yáng", "羊"),
    PracticeItem("声母 y", "yòng", "用"),
    PracticeItem("声母 w", "wǒ", "我"),
    PracticeItem("声母 w", "wǎn", "晚"),
    PracticeItem("声母 w", "wèn", "问"),
    PracticeItem("复韵母 ia", "xià", "下"),
    PracticeItem("复韵母 iao", "jiǎo", "脚"),
    PracticeItem("复韵母 ian", "tiān", "天"),
    PracticeItem("复韵母 iang", "liǎng", "两"),
    PracticeItem("复韵母 iong", "xiōng", "兄"),
    PracticeItem("复韵母 ua", "huā", "花"),
    PracticeItem("复韵母 uo", "guǒ", "果"),
    PracticeItem("复韵母 uai", "kuài", "快"),
    PracticeItem("复韵母 uan", "chuān", "穿"),
    PracticeItem("复韵母 uang", "chuáng", "床"),
    PracticeItem("前鼻韵母 ian", "miàn", "面"),
    PracticeItem("前鼻韵母 ian", "diàn", "电"),
    PracticeItem("前鼻韵母 ian", "xiān", "先"),
    PracticeItem("前鼻韵母 en", "mén", "门"),
    PracticeItem("前鼻韵母 en", "běn", "本"),
    PracticeItem("前鼻韵母 en", "shēn", "身"),
    PracticeItem("后鼻韵母 eng", "lěng", "冷"),
    PracticeItem("后鼻韵母 eng", "chéng", "成"),
    PracticeItem("后鼻韵母 eng", "dēng", "灯"),
    PracticeItem("后鼻韵母 ing", "tīng", "听"),
    PracticeItem("后鼻韵母 ing", "míng", "明"),
    PracticeItem("后鼻韵母 ing", "bǐng", "饼"),
    PracticeItem("后鼻韵母 ang", "fáng", "房"),
    PracticeItem("后鼻韵母 ang", "táng", "糖"),
    PracticeItem("后鼻韵母 ang", "xiàng", "向"),
    PracticeItem("综合练习", "bái", "白"),
    PracticeItem("综合练习", "hóng", "红"),
    PracticeItem("综合练习", "huáng", "黄"),
    PracticeItem("综合练习", "lǜ", "绿"),
    PracticeItem("综合练习", "lán", "蓝"),
    PracticeItem("综合练习", "zǐ", "紫")
)

private enum class ExerciseMode(val title: String, val prompt: String) {
    TYPE_CHARACTER("输入汉字", "根据拼音输入对应汉字"),
    CHOOSE_CHARACTER("看音选字", "请选择这个拼音对应的汉字"),
    CHOOSE_PINYIN("看字选音", "请选择这个汉字对应的拼音"),
    CHOOSE_INITIAL("补全声母", "选择缺失的声母"),
    CHOOSE_FINAL("补全韵母", "选择缺失的韵母"),
    CHOOSE_TONE("辨认声调", "选择这个音节的声调")
}

private data class ExerciseQuestion(
    val mode: ExerciseMode,
    val options: List<String>,
    val key: String
)

private val initialsPool = listOf(
    "b", "p", "m", "f", "d", "t", "n", "l", "g", "k", "h",
    "j", "q", "x", "zh", "ch", "sh", "r", "z", "c", "s", "y", "w"
)
private val tonesPool = listOf("1", "2", "3", "4")

private fun stripPinyinTone(pinyin: String): String {
    val map = mapOf(
        'ā' to 'a', 'á' to 'a', 'ǎ' to 'a', 'à' to 'a',
        'ē' to 'e', 'é' to 'e', 'ě' to 'e', 'è' to 'e',
        'ī' to 'i', 'í' to 'i', 'ǐ' to 'i', 'ì' to 'i',
        'ō' to 'o', 'ó' to 'o', 'ǒ' to 'o', 'ò' to 'o',
        'ū' to 'u', 'ú' to 'u', 'ǔ' to 'u', 'ù' to 'u',
        'ǖ' to 'ü', 'ǘ' to 'ü', 'ǚ' to 'ü', 'ǜ' to 'ü'
    )
    return pinyin.lowercase().map { map[it] ?: it }.joinToString("")
}

private fun initialOf(pinyin: String): String {
    val base = stripPinyinTone(pinyin)
    return listOf("zh", "ch", "sh").firstOrNull { base.startsWith(it) }
        ?: initialsPool.firstOrNull { base.startsWith(it) }
        ?: ""
}

private fun initialKey(pinyin: String): String = initialOf(pinyin).ifBlank { "零声母" }

private fun finalFromPinyin(pinyin: String): String {
    val base = stripPinyinTone(pinyin)
    val initial = initialOf(pinyin)
    var result = base.removePrefix(initial)
    // Pinyin writes the ü finals as u after y (yu, yue, yuan, yun).
    if (initial == "y") result = when (result) {
        "u" -> "ü"
        "ue" -> "üe"
        "uan" -> "üan"
        "un" -> "ün"
        else -> result
    }
    // After j/q/x, written "u" represents the ü sound in standard pinyin.
    if (initial in listOf("j", "q", "x") && result.startsWith("u")) {
        result = "ü" + result.drop(1)
    }
    return result
}

private fun finalOf(item: PracticeItem): String {
    val group = item.finalGroup
    return if (group.startsWith("声母") || group == "综合练习") {
        finalFromPinyin(item.pinyin)
    } else {
        group.substringAfter(' ', finalFromPinyin(item.pinyin))
    }
}

private fun toneOf(pinyin: String): String {
    val p = pinyin.lowercase()
    return when {
        p.any { it in "āēīōūǖ" } -> "1"
        p.any { it in "áéíóúǘ" } -> "2"
        p.any { it in "ǎěǐǒǔǚ" } -> "3"
        p.any { it in "àèìòùǜ" } -> "4"
        else -> "1"
    }
}

private fun serializeCounts(counts: Map<String, Int>): String =
    counts.entries.joinToString(";") { "${it.key}:${it.value}" }

private fun parseCounts(raw: String): Map<String, Int> = raw.split(';')
    .mapNotNull { entry ->
        val parts = entry.split(':', limit = 2)
        if (parts.size == 2) parts[0].takeIf { it.isNotBlank() }?.let { key ->
            parts[1].toIntOrNull()?.let { value -> key to value }
        } else null
    }.toMap()

private fun makeExerciseQuestion(
    itemIndex: Int,
    usedKeys: Set<String>,
    initialCounts: Map<String, Int>,
    finalCounts: Map<String, Int>
): ExerciseQuestion {
    val item = practiceItems[itemIndex]
    val initial = initialKey(item.pinyin)
    val final = finalOf(item)
    val mayRepeat = (initialCounts[initial] ?: 0) >= 50 && (finalCounts[final] ?: 0) >= 50
    val characterPool = practiceItems.map { it.target }.distinct()
    val pinyinPool = practiceItems.map { it.pinyin }.distinct()
    val finalPool = practiceItems.map { finalOf(it) }.distinct().filter { it.isNotBlank() }
    val initialPool = (initialsPool + "零声母" + initial).distinct().filter { it.isNotBlank() }

    fun makeCandidate(): ExerciseQuestion {
        val mode = ExerciseMode.entries.toList().random()
        val answer = when (mode) {
            ExerciseMode.TYPE_CHARACTER, ExerciseMode.CHOOSE_CHARACTER -> item.target
            ExerciseMode.CHOOSE_PINYIN -> item.pinyin
            ExerciseMode.CHOOSE_INITIAL -> initial
            ExerciseMode.CHOOSE_FINAL -> final
            ExerciseMode.CHOOSE_TONE -> toneOf(item.pinyin)
        }
        val pool = when (mode) {
            ExerciseMode.CHOOSE_CHARACTER -> characterPool
            ExerciseMode.CHOOSE_PINYIN -> pinyinPool
            ExerciseMode.CHOOSE_INITIAL -> initialPool
            ExerciseMode.CHOOSE_FINAL -> finalPool
            ExerciseMode.CHOOSE_TONE -> tonesPool
            ExerciseMode.TYPE_CHARACTER -> emptyList()
        }
        val options = if (mode == ExerciseMode.TYPE_CHARACTER) emptyList() else {
            (pool.filter { it != answer }.shuffled().take(3) + answer).distinct().shuffled()
        }
        val key = "$itemIndex|${mode.name}|${options.sorted().joinToString("~")}"
        return ExerciseQuestion(mode, options, key)
    }

    // Choice distractors are randomized. This creates many different versions of each exercise.
    repeat(500) {
        val candidate = makeCandidate()
        if (candidate.key !in usedKeys || mayRepeat) return candidate
    }
    // Very unlikely fallback, but always keep the app usable if local history grows unusually large.
    return makeCandidate()
}

private fun expectedAnswer(item: PracticeItem, question: ExerciseQuestion): String = when (question.mode) {
    ExerciseMode.TYPE_CHARACTER, ExerciseMode.CHOOSE_CHARACTER -> item.target
    ExerciseMode.CHOOSE_PINYIN -> item.pinyin
    ExerciseMode.CHOOSE_INITIAL -> initialKey(item.pinyin)
    ExerciseMode.CHOOSE_FINAL -> finalOf(item)
    ExerciseMode.CHOOSE_TONE -> toneOf(item.pinyin)
}

private fun answerLabel(question: ExerciseQuestion, answer: String): String = when {
    question.mode == ExerciseMode.CHOOSE_TONE -> "第${answer}声"
    question.mode == ExerciseMode.CHOOSE_INITIAL && answer == "零声母" -> "零声母（无声母）"
    else -> answer
}

private val Ink = Color(0xFF17233C)
private val Muted = Color(0xFF64718A)
private val Blue = Color(0xFF4169E1)
private val Page = Color(0xFFF5F7FB)
private val Green = Color(0xFF18865C)
private val Red = Color(0xFFB42318)

/** Load a complete saved shuffle order, or return null when it is missing/invalid. */
private fun readSavedQuestionOrder(prefs: android.content.SharedPreferences): List<Int>? {
    val saved = prefs.getString("question_order", "").orEmpty()
        .split(",").mapNotNull { it.toIntOrNull() }
    return saved.takeIf {
        it.size == practiceItems.size && it.toSet() == practiceItems.indices.toSet()
    }
}

/** Shuffle each full round, avoiding the previous round's last item as the next first item. */
private fun createQuestionOrder(previousLast: Int? = null): List<Int> {
    val order = practiceItems.indices.shuffled().toMutableList()
    if (order.size > 1 && order.first() == previousLast) {
        val first = order[0]
        order[0] = order[1]
        order[1] = first
    }
    return order
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { PinyinApp(this) } }
    }
}

@Composable
private fun PinyinApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("pinyin_practice", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var token by remember { mutableStateOf(prefs.getString("token", null).orEmpty()) }
    var username by remember { mutableStateOf(prefs.getString("username", "").orEmpty()) }
    var questionOrder by remember { mutableStateOf(readSavedQuestionOrder(prefs) ?: createQuestionOrder()) }
    var deckPosition by remember {
        mutableIntStateOf(
            if (readSavedQuestionOrder(prefs) != null)
                prefs.getInt("deck_position", 0).coerceIn(0, practiceItems.lastIndex)
            else 0
        )
    }
    var index by remember { mutableIntStateOf(questionOrder[deckPosition]) }
    var initialCounts by remember { mutableStateOf(parseCounts(prefs.getString("initial_counts", "").orEmpty())) }
    var finalCounts by remember { mutableStateOf(parseCounts(prefs.getString("final_counts", "").orEmpty())) }
    var seenQuestionKeys by remember { mutableStateOf(prefs.getStringSet("seen_question_keys", mutableSetOf<String>()).orEmpty().toSet()) }
    var wrongItemIndices by remember { mutableStateOf(prefs.getStringSet("wrong_item_indices", mutableSetOf<String>()).orEmpty().mapNotNull { it.toIntOrNull() }.toSet()) }
    var reviewMode by remember { mutableStateOf(false) }
    var exercise by remember { mutableStateOf(makeExerciseQuestion(index, seenQuestionKeys, initialCounts, finalCounts)) }
    var typed by remember { mutableStateOf("") }
    var attempts by remember { mutableIntStateOf(prefs.getInt("attempts", 0)) }
    var correct by remember { mutableIntStateOf(prefs.getInt("correct", 0)) }
    var checked by remember { mutableStateOf(false) }
    var isCorrect by remember { mutableStateOf(false) }
    var authMode by remember { mutableStateOf("登录") }
    var authUser by remember { mutableStateOf("") }
    var authPassword by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("尚未测试服务器连接") }
    var busy by remember { mutableStateOf(false) }
    var showAccount by remember { mutableStateOf(token.isBlank()) }
    val item = practiceItems[index]
    val accuracy = if (attempts == 0) 0 else correct * 100 / attempts

    fun saveLocal() {
        prefs.edit()
            .putInt("index", index)
            .putString("question_order", questionOrder.joinToString(","))
            .putInt("deck_position", deckPosition)
            .putInt("attempts", attempts)
            .putInt("correct", correct)
            .putString("initial_counts", serializeCounts(initialCounts))
            .putString("final_counts", serializeCounts(finalCounts))
            .putStringSet("seen_question_keys", (seenQuestionKeys + exercise.key).toMutableSet())
            .putStringSet("wrong_item_indices", wrongItemIndices.map { it.toString() }.toSet())
            .apply()
    }
    fun nextQuestion() {
        val updatedSeen = seenQuestionKeys + exercise.key
        seenQuestionKeys = updatedSeen
        if (reviewMode && wrongItemIndices.isNotEmpty()) {
            // Stay in the wrong-answer queue until its items are answered correctly.
            index = wrongItemIndices.random()
        } else {
            reviewMode = false
            if (deckPosition >= questionOrder.lastIndex) {
                questionOrder = createQuestionOrder(questionOrder.lastOrNull())
                deckPosition = 0
            } else {
                deckPosition++
            }
            index = questionOrder[deckPosition]
        }
        exercise = makeExerciseQuestion(index, updatedSeen, initialCounts, finalCounts)
        // Reserve the newly displayed question so it cannot recur before both related counters reach 50.
        seenQuestionKeys = updatedSeen + exercise.key
        typed = ""
        checked = false
        isCorrect = false
        saveLocal()
    }
    fun startOrStopReview() {
        if (reviewMode) {
            reviewMode = false
            typed = ""
            checked = false
            isCorrect = false
        } else if (wrongItemIndices.isNotEmpty()) {
            val updatedSeen = seenQuestionKeys + exercise.key
            reviewMode = true
            index = wrongItemIndices.random()
            exercise = makeExerciseQuestion(index, updatedSeen, initialCounts, finalCounts)
            seenQuestionKeys = updatedSeen + exercise.key
            typed = ""
            checked = false
            isCorrect = false
        }
        saveLocal()
    }
    fun submitAnswer(value: String = typed) {
        if (value.trim().isEmpty() || checked) return
        val expected = expectedAnswer(item, exercise)
        isCorrect = value.trim().equals(expected, ignoreCase = true)
        typed = value.trim()
        attempts++
        if (isCorrect) {
            correct++
            val initial = initialKey(item.pinyin)
            val final = finalOf(item)
            initialCounts = initialCounts + (initial to ((initialCounts[initial] ?: 0) + 1))
            finalCounts = finalCounts + (final to ((finalCounts[final] ?: 0) + 1))
            wrongItemIndices = wrongItemIndices - index
        } else {
            wrongItemIndices = wrongItemIndices + index
        }
        checked = true
        seenQuestionKeys = seenQuestionKeys + exercise.key
        saveLocal()
        if (isCorrect) {
            // Briefly show the success message, then automatically advance.
            scope.launch {
                delay(450)
                nextQuestion()
            }
        }
    }
    fun syncNow() {
        if (token.isBlank()) { message = "请先登录账号，再同步成绩。"; return }
        busy = true
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { ApiClient.putProgress(token, index, attempts, correct) }
                message = "云端同步成功：${result.optString("message", "成绩已保存")}" 
            } catch (e: Exception) { message = "同步失败：${e.message ?: "网络错误"}" }
            busy = false
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Page) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("拼音打字练习", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text(if (token.isNotBlank()) "已登录：$username · 云端可同步" else "6 种题型随机出题 · 声母/韵母独立计数 · 进度本机保存", fontSize = 12.sp, color = Muted)
                }
                Box(Modifier.size(46.dp).background(Color(0xFFE6ECFF), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) { Text("拼", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Blue) }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = {
                    busy = true
                    scope.launch {
                        message = try { val r = withContext(Dispatchers.IO) { ApiClient.health() }; "服务器连接成功：${r.optString("status", "ok")}" }
                        catch (e: Exception) { "连接失败：${e.message ?: "请检查服务器地址、端口和防火墙"}" }
                        busy = false
                    }
                }, modifier = Modifier.weight(1f)) { Text(if (busy) "请稍候…" else "测试服务器") }
                OutlinedButton(onClick = { showAccount = !showAccount }, modifier = Modifier.weight(1f)) { Text(if (showAccount) "返回练习" else if (token.isBlank()) "账号登录" else "账号/退出") }
                OutlinedButton(onClick = { startOrStopReview() }, modifier = Modifier.weight(1f), enabled = reviewMode || wrongItemIndices.isNotEmpty()) { Text(if (reviewMode) "退出错题" else "错题 ${wrongItemIndices.size}") }
            }
            Text(message, color = if (message.contains("成功")) Green else Muted, fontSize = 12.sp)

            if (showAccount) {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(if (token.isNotBlank()) "账号状态" else "账号与云端同步", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
                        if (token.isNotBlank()) {
                            Text("当前账号：$username", color = Muted)
                            Button(onClick = { syncNow() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("立即同步练习成绩") }
                            OutlinedButton(onClick = {
                                token = ""; username = ""; showAccount = true
                                prefs.edit().remove("token").remove("username").apply()
                                message = "已退出当前账号，本机练习记录仍保留。"
                            }, modifier = Modifier.fillMaxWidth()) { Text("退出登录") }
                        } else {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { authMode = "登录" }, modifier = Modifier.weight(1f)) { Text(if (authMode == "登录") "✓ 登录" else "登录") }
                                OutlinedButton(onClick = { authMode = "注册" }, modifier = Modifier.weight(1f)) { Text(if (authMode == "注册") "✓ 注册" else "注册") }
                            }
                            OutlinedTextField(value = authUser, onValueChange = { authUser = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("用户名（3–32 位：字母、数字、._-）") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next))
                            OutlinedTextField(value = authPassword, onValueChange = { authPassword = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("密码（至少 8 位）") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done))
                            Button(onClick = {
                                val u = authUser.trim(); val p = authPassword
                                if (!u.matches(Regex("^[A-Za-z0-9_.-]{3,32}$")) || p.length < 8) {
                                    message = "用户名需 3–32 位（仅限英文字母、数字、点、下划线、短横线），密码至少 8 位。"
                                    return@Button
                                }
                                busy = true
                                scope.launch {
                                    try {
                                        val r = withContext(Dispatchers.IO) { if (authMode == "注册") ApiClient.register(u, p) else ApiClient.login(u, p) }
                                        token = r.getString("access_token"); username = r.optJSONObject("user")?.optString("username", u) ?: u
                                        prefs.edit().putString("token", token).putString("username", username).apply()
                                        val remote = withContext(Dispatchers.IO) { ApiClient.getProgress(token) }
                                        index = remote.optInt("current_index", index).coerceIn(0, practiceItems.lastIndex)
                                        deckPosition = questionOrder.indexOf(index).coerceAtLeast(0)
                                        exercise = makeExerciseQuestion(index, seenQuestionKeys, initialCounts, finalCounts)
                                        typed = ""; checked = false; isCorrect = false
                                        attempts = remote.optInt("attempts", attempts).coerceAtLeast(0)
                                        correct = remote.optInt("correct", correct).coerceIn(0, attempts)
                                        saveLocal(); showAccount = false; typed = ""; checked = false
                                        message = "${authMode}成功，已读取云端练习进度。"
                                    } catch (e: Exception) { message = "${authMode}失败：${e.message ?: "网络错误"}" }
                                    busy = false
                                }
                            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "正在处理…" else authMode) }
                            Text("提示：当前配置为 HTTP 测试地址，请勿使用真实或重要密码。正式使用前必须部署 HTTPS。", color = Red, fontSize = 12.sp, lineHeight = 18.sp)
                        }
                    }
                }
            } else {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (reviewMode) "错题复习 · 剩余 ${wrongItemIndices.size} 道" else "练习进度", color = Muted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Text(if (reviewMode) "复习中" else "${deckPosition + 1} / ${practiceItems.size}", color = Blue, fontWeight = FontWeight.SemiBold)
                        }
                        LinearProgressIndicator(progress = { if (reviewMode) 1f else (deckPosition + 1f) / practiceItems.size }, modifier = Modifier.fillMaxWidth().height(7.dp), color = Blue, trackColor = Color(0xFFE9EDF5))
                        Text("${if (reviewMode) "错题复习  ·  " else ""}${item.finalGroup}  ·  ${exercise.mode.title}", color = Blue, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                when (exercise.mode) {
                                    ExerciseMode.TYPE_CHARACTER, ExerciseMode.CHOOSE_CHARACTER -> item.pinyin
                                    ExerciseMode.CHOOSE_PINYIN -> item.target
                                    ExerciseMode.CHOOSE_INITIAL -> "＿${finalOf(item)}"
                                    ExerciseMode.CHOOSE_FINAL -> "${initialOf(item.pinyin)}＿"
                                    ExerciseMode.CHOOSE_TONE -> stripPinyinTone(item.pinyin)
                                },
                                fontSize = 42.sp, fontWeight = FontWeight.Bold, color = Ink
                            )
                            Text(exercise.mode.prompt, fontSize = 13.sp, color = Muted, textAlign = TextAlign.Center)
                        }
                        if (exercise.mode == ExerciseMode.TYPE_CHARACTER) {
                            OutlinedTextField(value = typed, onValueChange = { typed = it; checked = false }, modifier = Modifier.fillMaxWidth(), enabled = !checked, singleLine = true, label = { Text("输入汉字") }, placeholder = { Text("切换到中文输入法") }, shape = RoundedCornerShape(14.dp), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), keyboardActions = KeyboardActions(onDone = { submitAnswer() }))
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                exercise.options.forEach { option ->
                                    OutlinedButton(
                                        onClick = { submitAnswer(option) },
                                        enabled = !checked,
                                        modifier = Modifier.fillMaxWidth().height(46.dp),
                                        shape = RoundedCornerShape(13.dp)
                                    ) { Text(answerLabel(exercise, option), fontSize = 17.sp) }
                                }
                            }
                        }
                        if (checked) {
                            val rightAnswer = answerLabel(exercise, expectedAnswer(item, exercise))
                            Text(if (isCorrect) "回答正确！继续保持。" else "正确答案：$rightAnswer", color = if (isCorrect) Green else Red, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                        }
                        if (exercise.mode == ExerciseMode.TYPE_CHARACTER) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                Button(onClick = { submitAnswer() }, enabled = typed.trim().isNotEmpty() && !checked, modifier = Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text("检查答案", fontWeight = FontWeight.SemiBold) }
                                OutlinedButton(onClick = { nextQuestion() }, enabled = !(checked && isCorrect), modifier = Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(14.dp)) { Text(if (checked && isCorrect) "正在进入下一题…" else if (deckPosition == questionOrder.lastIndex) "新一轮随机出题" else "跳过 / 下一题") }
                            }
                        } else {
                            OutlinedButton(onClick = { nextQuestion() }, enabled = !(checked && isCorrect), modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(13.dp)) { Text(if (checked && isCorrect) "正在进入下一题…" else if (deckPosition == questionOrder.lastIndex) "新一轮随机出题" else "跳过 / 下一题") }
                        }
                        if (checked && exercise.mode == ExerciseMode.TYPE_CHARACTER) TextButton(onClick = { typed = ""; checked = false; isCorrect = false }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("重新输入") }
                        Button(onClick = { syncNow() }, enabled = token.isNotBlank() && !busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(if (busy) "正在同步…" else "同步到云端") }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    StatCard("累计答题", "$attempts", Modifier.weight(1f)); StatCard("答对题数", "$correct", Modifier.weight(1f)); StatCard("正确率", "$accuracy%", Modifier.weight(1f))
                }
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("知识点掌握进度（答对才累计）", color = Ink, fontWeight = FontWeight.Bold)
                        val currentInitial = initialKey(item.pinyin)
                        val currentFinal = finalOf(item)
                        Text("声母 $currentInitial：${initialCounts[currentInitial] ?: 0} / 50 次", color = Muted, fontSize = 13.sp)
                        LinearProgressIndicator(progress = { ((initialCounts[currentInitial] ?: 0).coerceAtMost(50)) / 50f }, modifier = Modifier.fillMaxWidth().height(6.dp), color = Blue, trackColor = Color(0xFFE9EDF5))
                        Text("韵母 $currentFinal：${finalCounts[currentFinal] ?: 0} / 50 次", color = Muted, fontSize = 13.sp)
                        LinearProgressIndicator(progress = { ((finalCounts[currentFinal] ?: 0).coerceAtMost(50)) / 50f }, modifier = Modifier.fillMaxWidth().height(6.dp), color = Green, trackColor = Color(0xFFE9EDF5))
                        Text("规则：同一道题（题型和选项组合也相同）只有在对应声母、韵母都累计答对 50 次后，才允许再次出现。", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF3FF)), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("连接信息", fontWeight = FontWeight.Bold, color = Ink)
                        Text("服务器：${ApiClient.BASE_URL}\n接口：/health、/api/register、/api/login、/api/progress", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                        Text("若接口不存在，请部署项目内 backend/main.py；当前网络地址为 HTTP，仅供联调。", color = Red, fontSize = 12.sp, lineHeight = 18.sp)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 15.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, color = Ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        }
    }
}
