@echo off
setlocal
cd /d "%~dp0"
echo ==============================================
echo Pinyin Practice Android - Build Debug APK
echo ==============================================
set "GRADLE_CMD="
where gradle >nul 2>nul
if not errorlevel 1 set "GRADLE_CMD=gradle"
if not defined GRADLE_CMD if defined USERPROFILE (
  for /f "delims=" %%G in ('dir /b /s "%USERPROFILE%\.gradle\wrapper\dists\gradle-8.9-bin\*\gradle-8.9\bin\gradle.bat" 2^>nul') do if not defined GRADLE_CMD set "GRADLE_CMD=%%G"
)
if not defined GRADLE_CMD (
  echo Gradle 8.9 was not found.
  echo First open this project in Android Studio and allow Gradle Sync to finish,
  echo or install Gradle 8.9 and add it to PATH. Android SDK Platform 35 is also required.
  pause
  exit /b 1
)
echo Using Gradle: %GRADLE_CMD%
call "%GRADLE_CMD%" --version
if errorlevel 1 goto failed
call "%GRADLE_CMD%" --no-daemon :app:assembleDebug
if errorlevel 1 goto failed
echo.
echo BUILD SUCCESS. APK location:
echo %CD%\app\build\outputs\apk\debug\app-debug.apk
if exist "app\build\outputs\apk\debug\app-debug.apk" explorer /select,"%CD%\app\build\outputs\apk\debug\app-debug.apk"
pause
exit /b 0
:failed
echo.
echo BUILD FAILED. Copy the complete error text and send it for troubleshooting.
pause
exit /b 1
