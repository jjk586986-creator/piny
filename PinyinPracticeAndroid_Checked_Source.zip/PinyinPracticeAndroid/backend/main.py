"""API backend paired with the PinyinPracticeAndroid app.

For real use, serve this app behind HTTPS (Nginx + a valid TLS certificate).
Do not expose this development HTTP service directly to the public Internet.
"""
from __future__ import annotations
import base64
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import time
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, Header, HTTPException, Depends
from pydantic import BaseModel, Field

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("PINYIN_DATA_DIR", str(APP_DIR / "data")))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "pinyin.sqlite3"
SECRET_PATH = DATA_DIR / ".token_secret"
if not SECRET_PATH.exists():
    fd = os.open(str(SECRET_PATH), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(secrets.token_bytes(32))
SECRET = SECRET_PATH.read_bytes()
TOKEN_TTL_SECONDS = 30 * 24 * 60 * 60

app = FastAPI(title="拼音练习 APP 接口", version="1.1.0")


def db_connect():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    with db_connect() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            salt TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            created_at INTEGER NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS progress (
            user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
            current_index INTEGER NOT NULL DEFAULT 0,
            attempts INTEGER NOT NULL DEFAULT 0,
            correct INTEGER NOT NULL DEFAULT 0,
            updated_at INTEGER NOT NULL
        )""")

init_db()

class AuthIn(BaseModel):
    username: str = Field(min_length=3, max_length=32, pattern=r"^[A-Za-z0-9_.-]+$")
    password: str = Field(min_length=8, max_length=128)

class ProgressIn(BaseModel):
    current_index: int = Field(ge=0, le=5000)
    attempts: int = Field(ge=0, le=100000000)
    correct: int = Field(ge=0, le=100000000)


def b64url(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def make_token(user_id: int, username: str) -> str:
    payload = b64url(json.dumps({"sub": user_id, "username": username, "exp": int(time.time()) + TOKEN_TTL_SECONDS}, separators=(",", ":")).encode())
    signature = b64url(hmac.new(SECRET, payload.encode(), hashlib.sha256).digest())
    return payload + "." + signature


def get_current_user(authorization: Optional[str] = Header(default=None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="请先登录")
    token = authorization[7:].strip()
    try:
        payload_part, sig_part = token.split(".", 1)
        expected = b64url(hmac.new(SECRET, payload_part.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(sig_part, expected):
            raise ValueError("signature")
        payload = json.loads(base64.urlsafe_b64decode(payload_part + "=" * (-len(payload_part) % 4)))
        if int(payload.get("exp", 0)) < int(time.time()):
            raise ValueError("expired")
        return {"id": int(payload["sub"]), "username": str(payload["username"])}
    except Exception:
        raise HTTPException(status_code=401, detail="登录已失效，请重新登录")


def hash_password(password: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 310000).hex()

@app.get("/")
def home():
    return {"message": "拼音练习 APP 后端运行正常", "version": "1.1.0"}

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/api/register")
def register(data: AuthIn):
    salt = secrets.token_bytes(16)
    digest = hash_password(data.password, salt)
    try:
        with db_connect() as conn:
            cur = conn.execute("INSERT INTO users(username, salt, password_hash, created_at) VALUES (?, ?, ?, ?)",
                               (data.username, b64url(salt), digest, int(time.time())))
            user_id = int(cur.lastrowid)
            conn.execute("INSERT INTO progress(user_id, updated_at) VALUES (?, ?)", (user_id, int(time.time())))
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="用户名已存在")
    return {"access_token": make_token(user_id, data.username), "token_type": "bearer", "user": {"id": user_id, "username": data.username}}

@app.post("/api/login")
def login(data: AuthIn):
    with db_connect() as conn:
        user = conn.execute("SELECT id, username, salt, password_hash FROM users WHERE username=?", (data.username,)).fetchone()
    if not user:
        raise HTTPException(status_code=401, detail="用户名或密码错误")
    salt = base64.urlsafe_b64decode(user["salt"] + "=" * (-len(user["salt"]) % 4))
    if not hmac.compare_digest(hash_password(data.password, salt), user["password_hash"]):
        raise HTTPException(status_code=401, detail="用户名或密码错误")
    return {"access_token": make_token(int(user["id"]), user["username"]), "token_type": "bearer", "user": {"id": int(user["id"]), "username": user["username"]}}

@app.get("/api/progress")
def get_progress(user=Depends(get_current_user)):
    with db_connect() as conn:
        row = conn.execute("SELECT current_index, attempts, correct, updated_at FROM progress WHERE user_id=?", (user["id"],)).fetchone()
    if not row:
        return {"current_index": 0, "attempts": 0, "correct": 0, "updated_at": int(time.time())}
    return dict(row)

@app.put("/api/progress")
def put_progress(data: ProgressIn, user=Depends(get_current_user)):
    if data.correct > data.attempts:
        raise HTTPException(status_code=422, detail="答对题数不能大于累计答题数")
    now = int(time.time())
    with db_connect() as conn:
        conn.execute("""INSERT INTO progress(user_id, current_index, attempts, correct, updated_at)
            VALUES (?, ?, ?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET
            current_index=excluded.current_index, attempts=excluded.attempts,
            correct=excluded.correct, updated_at=excluded.updated_at""",
            (user["id"], data.current_index, data.attempts, data.correct, now))
    return {"message": "成绩已保存", "current_index": data.current_index, "attempts": data.attempts, "correct": data.correct, "updated_at": now}
