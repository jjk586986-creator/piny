# 后端接入说明（请先阅读）

Android 客户端当前配置地址：`http://47.88.2.116:8000`

客户端需要以下接口：
- `GET /health`
- `POST /api/register`，JSON: `{"username":"abc","password":"至少8位"}`
- `POST /api/login`，JSON 同上，返回 `access_token` 和 `user`
- `GET /api/progress`，请求头 `Authorization: Bearer <access_token>`
- `PUT /api/progress`，请求头同上，JSON: `{"current_index":0,"attempts":0,"correct":0}`

## 在阿里云服务器部署（先备份）

1. 先在 Workbench 终端运行 `pwd`，确认原后端目录，再备份原文件，例如：
   `cp ~/pinyin-backend/main.py ~/pinyin-backend/main.py.bak`
2. 将本目录的 `main.py` 上传到服务器原后端目录，覆盖前先确认备份存在。
3. 在对应虚拟环境里执行：
   `python -m pip install -r requirements.txt`
4. 用你现有的 systemd 服务重启后端。先通过 `systemctl list-units --type=service | grep -i pinyin` 找实际服务名，再 `sudo systemctl restart <实际服务名>`。
5. 查看 `sudo systemctl status <实际服务名>`，再在浏览器测试 `/health` 和 `/docs`。

**重要安全说明：** 当前 Android 配置的是 HTTP 测试地址。HTTP 不加密，会暴露登录密码和令牌，不能用于真实账号/生产环境。正式使用前必须给域名配置 HTTPS 证书（通常由 Nginx 反向代理到本机 Uvicorn），并把 Android 的 `ApiClient.kt` 中 `BASE_URL` 改成 `https://你的域名`，同时移除 Manifest 的 `usesCleartextTraffic`。不要开放 PostgreSQL/SQLite 数据库文件给公网，也不要把密钥发给别人。

后端将数据保存在 `backend/data/pinyin.sqlite3`，令牌签名密钥在 `backend/data/.token_secret` 自动生成。部署时请把整个数据目录保存在固定位置并做好备份，不要随意删除密钥文件，否则已有登录令牌会失效。
